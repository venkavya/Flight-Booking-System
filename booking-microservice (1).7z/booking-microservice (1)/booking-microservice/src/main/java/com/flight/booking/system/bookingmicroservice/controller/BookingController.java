package com.flight.booking.system.bookingmicroservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.flight.booking.system.bookingmicroservice.entity.Booking;
import com.flight.booking.system.bookingmicroservice.entity.Checkin;
import com.flight.booking.system.bookingmicroservice.service.BookingService;

@RestController
@RequestMapping("/book")
public class BookingController {
    
    @Autowired
    private BookingService bookingService;
   
    @GetMapping("/getallbookings")
    public List<Booking> findAllbooking() {
        return bookingService.findAllBookings();
        }
    
    @GetMapping("/get/{bookingId}")
    public Booking getByBookingId(@PathVariable("id") int bookingid) {
        return bookingService.getByBookingId(bookingid);
     }
    
    @PostMapping("/booking")
    public Booking adding(@RequestBody Booking booking) {
    return bookingService.saveBooking(booking);
    }
    
    @DeleteMapping("/delete/{id}")
    public Booking deleteById(@PathVariable int id) {
    	bookingService.deletebookingById(id);
    	return  bookingService.getByBookingId(id);
    }


    @PutMapping("/update/{bookingid}")  
    public Booking update(@RequestBody  Booking bookingid1,@PathVariable int bookingid)  {  
    return bookingService.updatebooking(bookingid1); 
    }

	/*
	 * @PutMapping("/update/{lastName}")
	 *  public Checkin checkin(@RequestBody Checkin checkin,@PathVariable("lastName") { 
	 * return checkin.(); }
	 */

}


