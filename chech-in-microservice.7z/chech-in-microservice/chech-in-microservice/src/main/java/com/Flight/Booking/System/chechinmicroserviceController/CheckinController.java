package com.Flight.Booking.System.chechinmicroserviceController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Flight.Booking.System.chechinmicroserviceEntity.Checkin;
import com.Flight.Booking.System.chechinmicroserviceService.CheckinService;

@RestController
@RequestMapping("/enter")
public class CheckinController {
	
	@Autowired
	 CheckinService checkinservice;
	
	public CheckinController(CheckinService checkinservice) {
		super();
		this.checkinservice = checkinservice;
	}
	



	public CheckinController() {
		super();
	}




	/*
	 * public CheckinController(CheckinService checkinservice) { this.checkinservice
	 * = checkinservice; }
	 * 
	 * @PostMapping("/flightCheckin") public Checkin adding(@RequestBody Checkin
	 * checkin) { return checkinservice.updatecheckinflightstatus(checkin); }
	 * 
	 * @GetMapping("getallflightstatuses") private List<Checkin>
	 * findAllflightstatus() { return CheckinService.findAllflightstatus(); }
	 */

	@GetMapping("/getallcheckin")
    public List<Checkin> findAllcheckin(){
        return checkinservice.findAllCheckins();
    }



      /* @GetMapping("/{seatnumber}")
        public Checkin getByseatNumber(@PathVariable String seatnumber){
            return checkinService.getByseatNumber(seatnumber);
        }*/
        @PostMapping("/checkin")
        public Checkin adding(@RequestBody Checkin checkin){
            return checkinservice.updateseatNumber(checkin);
        }



       @DeleteMapping("/delete/{seatnumber}")
        public void delete(@RequestBody String seatnumber){
            checkinservice.deleteByseatNumber(seatnumber);
        }



       @PutMapping("/update/{seatnumber}")
        public Checkin update(@RequestBody Checkin seatnumber1,@PathVariable String seatnumber) {
            return checkinservice.updateseatNumber(seatnumber1);
        }
	
}
