package com.Flight.Booking.System.chechinmicroserviceService;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.autoconfigure.metrics.MetricsProperties.Data.Repository;
import org.springframework.stereotype.Service;

import com.Flight.Booking.System.chechinmicroserviceEntity.Checkin;
import com.Flight.Booking.System.chechinmicroserviceRepository.CheckinRepository;

@Service
public class CheckinService {

	@Autowired
	private CheckinRepository checkinrepository;

	public List<Checkin> findAllCheckins() {
		return checkinrepository.findAll();
	}

	public Checkin updateseatNumber(Checkin checkin) {
		return checkinrepository.updateseatnumber(checkin);
	}

	public void deleteByseatNumber(String seatnumber) {
		checkinrepository.deleteByseatnumber(seatnumber);
		
	}

	

	/*
	 * public Checkin saveCheckin(Checkin checkin) { return
	 * CheckinRepository.save(checkin); }
	 * 
	 * public Checkin updatecheckinflightstatus(Checkin checkin) { return
	 * CheckinRepository.save(flightstatus); }
	 * 
	 * public static List<Checkin> findAllflightstatus() { return
	 * CheckinRepository.getAll(); }
	 */

	}
