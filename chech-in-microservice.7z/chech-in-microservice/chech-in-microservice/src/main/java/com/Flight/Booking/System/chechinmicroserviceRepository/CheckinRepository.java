package com.Flight.Booking.System.chechinmicroserviceRepository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.Flight.Booking.System.chechinmicroserviceEntity.Checkin;

import io.micrometer.core.instrument.search.Search;

@Repository
public interface CheckinRepository extends MongoRepository<Checkin,Long> {

	Checkin updateseatnumber(Checkin checkin);

	void deleteByseatnumber(String seatnumber);

 

		
}
