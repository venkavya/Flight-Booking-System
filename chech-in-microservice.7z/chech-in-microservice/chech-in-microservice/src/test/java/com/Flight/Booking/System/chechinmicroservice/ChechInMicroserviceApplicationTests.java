package com.Flight.Booking.System.chechinmicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChechInMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
